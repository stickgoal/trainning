package dev.langchain4j.agentic.internal;

import static dev.langchain4j.agentic.internal.AgentUtil.agenticSystemDataTypes;
import static dev.langchain4j.agentic.internal.AgentUtil.argumentsFromMethod;
import static dev.langchain4j.agentic.internal.AgentUtil.rawType;
import static dev.langchain4j.agentic.observability.ComposedAgentListener.composeWithInherited;
import static dev.langchain4j.agentic.observability.ComposedAgentListener.listenerOfType;
import static dev.langchain4j.agentic.observability.ListenerNotifierUtil.afterAgentInvocation;
import static dev.langchain4j.agentic.observability.ListenerNotifierUtil.beforeAgentInvocation;
import static dev.langchain4j.agentic.observability.ListenerNotifierUtil.afterAgenticScopeCreated;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.lang.reflect.Proxy;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import dev.langchain4j.agentic.UntypedAgent;
import dev.langchain4j.agentic.agent.ErrorContext;
import dev.langchain4j.agentic.agent.ErrorRecoveryResult;
import dev.langchain4j.agentic.observability.AgentListener;
import dev.langchain4j.agentic.observability.AgentMonitor;
import dev.langchain4j.agentic.observability.MonitoredAgent;
import dev.langchain4j.agentic.planner.Action;
import dev.langchain4j.agentic.planner.AgentArgument;
import dev.langchain4j.agentic.planner.AgentInstance;
import dev.langchain4j.agentic.planner.AgenticSystemTopology;
import dev.langchain4j.agentic.planner.InitPlanningContext;
import dev.langchain4j.agentic.planner.PlanningContext;
import dev.langchain4j.agentic.scope.AgentInvocation;
import dev.langchain4j.agentic.planner.ChatMemoryAccessProvider;
import dev.langchain4j.agentic.planner.Planner;
import dev.langchain4j.agentic.scope.AgenticScope;
import dev.langchain4j.agentic.scope.AgenticScopeAccess;
import dev.langchain4j.agentic.scope.AgenticScopeRegistry;
import dev.langchain4j.agentic.scope.DefaultAgenticScope;
import dev.langchain4j.agentic.scope.ResultWithAgenticScope;
import dev.langchain4j.agentic.workflow.impl.ParallelMapperServiceImpl;
import dev.langchain4j.internal.DefaultExecutorProvider;
import dev.langchain4j.service.MemoryId;
import dev.langchain4j.service.ParameterNameResolver;
import dev.langchain4j.service.TokenStream;
import dev.langchain4j.service.memory.ChatMemoryAccess;

public class PlannerBasedInvocationHandler implements InvocationHandler, InternalAgent {
    private final Executor executor;

    private final Function<AgenticScope, Object> output;

    protected AgentListener agentListener;

    private final Consumer<AgenticScope> beforeCall;

    private final DefaultAgenticScope agenticScope;

    private final Function<ErrorContext, ErrorRecoveryResult> errorHandler;

    private final AtomicReference<AgenticScopeRegistry> agenticScopeRegistry = new AtomicReference<>();

    private final AbstractServiceBuilder<?, ?> service;

    private final Supplier<Planner> plannerSupplier;

    private final Planner defaultPlannerInstance;

    private final Class<?> type;
    private final String name;
    private final String description;
    private final Type outputType;
    private boolean allowStreamingOutput;
    private final String outputKey;
    private final List<AgentArgument> arguments;
    private final List<AgentInstance> subagents;

    private String agentId;
    private InternalAgent parent;

    public PlannerBasedInvocationHandler(AbstractServiceBuilder<?, ?> service, Supplier<Planner> plannerSupplier) {
        this(service, null, service.name, plannerSupplier, null);

        for (int i = 0; i < service.subagents.size(); i++) {
            service.subagents.get(i).setParent(this, i);
        }
        agenticSystemDataTypes(this);
    }

    private PlannerBasedInvocationHandler(AbstractServiceBuilder<?, ?> service, InternalAgent parent, String agentId, Supplier<Planner> plannerSupplier, DefaultAgenticScope agenticScope) {
        this.service = service;
        this.agentId = agentId;
        this.output = service.output;
        this.executor = service.executor;
        this.beforeCall = service.beforeCall;
        this.errorHandler = service.errorHandler;
        this.agentListener = service.agentListener;
        this.plannerSupplier = plannerSupplier;
        this.defaultPlannerInstance = plannerSupplier.get();
        this.agenticScope = agenticScope;

        this.type = service.agentServiceClass;
        this.name = service.name;
        this.description = service.description;
        this.outputType = service.agentReturnType();
        this.allowStreamingOutput = UntypedAgent.class.isAssignableFrom(this.type) ||
                TokenStream.class.isAssignableFrom(rawType(this.outputType));
        this.outputKey = service.outputKey;
        this.arguments = service.agenticMethod != null ? argumentsFromMethod(service.agenticMethod) : List.of();
        this.subagents = service.subagents.stream().map(AgentInstance.class::cast).toList();
        setParent(parent);
    }

    public AgenticScopeOwner withAgenticScope(DefaultAgenticScope agenticScope) {
        return (AgenticScopeOwner) Proxy.newProxyInstance(
                type.getClassLoader(),
                new Class<?>[] {type, InternalAgent.class, AgenticScopeOwner.class},
                new PlannerBasedInvocationHandler(service, parent, agentId, plannerSupplier, agenticScope));
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Exception {
        AgenticScopeRegistry registry = agenticScopeRegistry();
        if (method.getDeclaringClass() == AgenticScopeOwner.class) {
            return switch (method.getName()) {
                case "withAgenticScope" -> withAgenticScope((DefaultAgenticScope) args[0]);
                case "registry" -> registry;
                default ->
                    throw new UnsupportedOperationException(
                            "Unknown method on AgenticScopeOwner class : " + method.getName());
            };
        }

        if (method.getDeclaringClass() == AgenticScopeAccess.class) {
            return switch (method.getName()) {
                case "getAgenticScope" -> registry.get(args[0]);
                case "evictAgenticScope" -> registry.evict(args[0], agentListener);
                default ->
                    throw new UnsupportedOperationException(
                            "Unknown method on AgenticScopeAccess class : " + method.getName());
            };
        }

        if (method.getDeclaringClass() == AgentInstance.class || method.getDeclaringClass() == InternalAgent.class) {
            try {
                return method.invoke(Proxy.getInvocationHandler(proxy), args);
            } catch (Exception e) {
                throw e.getCause() != null ? (Exception) e.getCause() : e;
            }
        }

        if (method.getDeclaringClass() == MonitoredAgent.class) {
            return listenerOfType(agentListener, AgentMonitor.class);
        }

        if (method.getDeclaringClass() == Object.class) {
            return switch (method.getName()) {
                case "toString" -> service.serviceType() + "<" + type.getSimpleName() + ">";
                case "hashCode" -> System.identityHashCode(this);
                default ->
                        throw new UnsupportedOperationException(
                                "Unknown method on Object class : " + method.getName());
            };
        }

        if (method.getDeclaringClass() == ChatMemoryAccess.class) {
            Object memoryId = args[0];
            return accessChatMemory(getOrCreateAgenticScope(registry, memoryId), method.getName(), memoryId);
        }

        return executeAgentMethod(registry, method, args);
    }

    private AgenticScopeRegistry agenticScopeRegistry() {
        if (isRootCall()) {
            agenticScopeRegistry.compareAndSet(null, new AgenticScopeRegistry(type.getName()));
        }
        return agenticScopeRegistry.get();
    }

    private Object executeAgentMethod(AgenticScopeRegistry registry, Method method, Object[] args) {
        DefaultAgenticScope currentScope = currentAgenticScope(registry, method, args);
        writeAgenticScope(currentScope, method, args);
        beforeCall.accept(currentScope);

        Map<String, Object> namedArgs = isRootCall() ? argToMap(method, args) : null;
        if (isRootCall()) {
            currentScope.rootCallStarted(registry);
            beforeAgentInvocation(agentListener, currentScope, this, namedArgs);
        }

        Planner planner = plannerSupplier.get();
        planner.init(new InitPlanningContext(currentScope, this, subagents));
        Object result = new PlannerLoop(planner, currentScope, registry).loop();
        Object output = outputKey != null ? currentScope.readState(outputKey) : result;

        if (isRootCall()) {
            afterAgentInvocation(agentListener, currentScope, this, namedArgs, output);
            currentScope.rootCallEnded(registry, agentListener);
        }

        return method.getReturnType().equals(ResultWithAgenticScope.class)
                ? new ResultWithAgenticScope<>(currentScope, output)
                : output;
    }

    private static Map<String, Object> argToMap(Method method, Object[] args) {
        if (method.getParameterCount() == 1 && Map.class.isAssignableFrom(method.getParameters()[0].getType())) {
            return (Map<String, Object>) args[0];
        }
        if (args == null || args.length == 0) {
            return Map.of();
        }
        Map<String, Object> namedArgs = new HashMap<>();
        for (int i = 0; i < args.length; i++) {
            namedArgs.put(ParameterNameResolver.name(method.getParameters()[i]), args[i]);
        }
        return namedArgs;
    }

    @Override
    public String toString() {
        return service.serviceType() + "<" + type.getSimpleName() + ">";
    }

    @Override
    public Class<?> type() {
        return type;
    }

    @Override
    public Class<? extends Planner> plannerType() {
        return defaultPlannerInstance.getClass();
    }

    @Override
    public String name() {
        return name;
    }

    @Override
    public String agentId() {
        return agentId;
    }

    @Override
    public String description() {
        return description;
    }

    @Override
    public Type outputType() {
        return outputType;
    }

    @Override
    public String outputKey() {
        return outputKey;
    }

    @Override
    public boolean async() {
        return false;
    }

    @Override
    public List<AgentArgument> arguments() {
        return arguments;
    }

    @Override
    public AgentInstance parent() {
        return parent;
    }

    @Override
    public void setParent(InternalAgent parent) {
        if (parent == null) {
            return;
        }
        this.parent = parent;
        registerInheritedParentListener(parent.listener());
        if (!parent.allowStreamingOutput()) {
            this.allowStreamingOutput = false;
        }
    }

    @Override
    public void registerInheritedParentListener(AgentListener parentListener) {
        if (parentListener != null && parentListener.inheritedBySubagents()) {
            agentListener = composeWithInherited(agentListener, parentListener);
            subagents().stream().map(InternalAgent.class::cast)
                    .forEach(agent -> agent.registerInheritedParentListener(parentListener));
        }
    }

    @Override
    public boolean allowStreamingOutput() {
        return allowStreamingOutput;
    }

    @Override
    public boolean allowChatMemory() {
        return !ParallelMapperServiceImpl.SERVICE_TYPE.equals(service.serviceType());
    }

    @Override
    public void appendId(String idSuffix) {
        this.agentId = this.agentId + idSuffix;
    }

    @Override
    public List<AgentInstance> subagents() {
        return subagents;
    }

    @Override
    public AgenticSystemTopology topology() {
        return defaultPlannerInstance.topology();
    }

    @Override
    public <T extends AgentInstance> T as(Class<T> agentInstanceClass) {
        return defaultPlannerInstance.as(agentInstanceClass, this);
    }

    @Override
    public AgentListener listener() {
        return agentListener;
    }

    private class PlannerLoop implements PlannerExecutor {
        static final String EXECUTION_STATE_PREFIX = "__planner_state_";

        private final Planner planner;
        private final DefaultAgenticScope agenticScope;
        private final AgenticScopeRegistry registry;
        private final ReentrantLock lock = new ReentrantLock();

        private volatile Action nextAction = null;

        private PlannerLoop(Planner planner, DefaultAgenticScope agenticScope, AgenticScopeRegistry registry) {
            this.planner = planner;
            this.agenticScope = agenticScope;
            this.registry = registry;
        }

        @SuppressWarnings("unchecked")
        public Object loop() {
            Map<String, Object> savedState = agenticScope.readState(executionStateId(), Map.of());
            if (!savedState.isEmpty()) {
                planner.restoreExecutionState(savedState);
            }

            nextAction = planner.firstAction(new PlanningContext(agenticScope, null));
            while (nextAction == null || !nextAction.isDone()) {
                if (nextAction == null) {
                    Thread.yield();
                    continue;
                }
                List<AgentExecutor> agents = ((Action.AgentCallAction) nextAction).agentsToCall();
                nextAction = null;
                switch (agents.size()) {
                    case 0 -> Thread.yield();
                    case 1 -> agents.get(0).execute(agenticScope, this);
                    default -> parallelExecution(agents);
                }
            }

            // Clear execution state when planner is done
            agenticScope.writeState(executionStateId(), null);

            return result();
        }

        private String executionStateId() {
            return EXECUTION_STATE_PREFIX + agentId();
        }

        private void parallelExecution(List<AgentExecutor> agents) {
            Executor exec = executor != null ? executor : DefaultExecutorProvider.getDefaultExecutorService();
            var tasks = agents.stream()
                    .map(agentExecutor -> CompletableFuture.supplyAsync(() -> agentExecutor.execute(agenticScope, this), exec))
                    .toArray(CompletableFuture[]::new);
            try {
                CompletableFuture.allOf(tasks).get();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new RuntimeException(e);
            } catch (ExecutionException e) {
                throw new RuntimeException(e);
            }
        }
        private Object result() {
            Object result = output != null ? output.apply(agenticScope) : nextAction.result();

            if (outputKey != null) {
                if (result != null) {
                    agenticScope.writeState(outputKey, result);
                    return result;
                } else {
                    return agenticScope.readState(outputKey);
                }
            }
            return result;
        }

        @Override
        public void onSubagentInvoked(AgentInvocation agentInvocation) {
            lock.lock();
            try {
                this.nextAction = composeActions(this.nextAction, planner.nextAction(new PlanningContext(agenticScope, agentInvocation)));

                // Save planner execution state after each agent invocation
                Map<String, Object> execState = planner.executionState();
                if (!execState.isEmpty()) {
                    agenticScope.writeState(executionStateId(), execState);
                }

                if (registry != null) {
                    agenticScope.checkpoint(registry);
                }
            } finally {
                lock.unlock();
            }
        }

        @Override
        public boolean propagateStreaming() {
            return allowStreamingOutput && planner.terminated();
        }

        private static Action composeActions(Action first, Action second) {
            if (first == null || first.isDone() || isEmptyCall(first)) {
                return second;
            }
            if (second == null || second.isDone() || isEmptyCall(second)) {
                return first;
            }

            List<AgentExecutor> agentsToCall = new ArrayList<>();
            agentsToCall.addAll(((Action.AgentCallAction) first).agentsToCall());
            agentsToCall.addAll(((Action.AgentCallAction) second).agentsToCall());
            return new Action.AgentCallAction(agentsToCall);
        }

        private static boolean isEmptyCall(Action action) {
            return action instanceof Action.AgentCallAction aca && aca.agentsToCall().isEmpty();
        }
    }

    private boolean isRootCall() {
        return this.agenticScope == null;
    }

    private static void writeAgenticScope(DefaultAgenticScope agenticScope, Method method, Object[] args) {
        if (method.getDeclaringClass() == UntypedAgent.class) {
            agenticScope.writeStates((Map<String, Object>) args[0]);
        } else {
            Parameter[] parameters = method.getParameters();
            for (int i = 0; i < parameters.length; i++) {
                int index = i;
                AgentInvoker.optionalParameterName(parameters[i])
                        .ifPresent(argName -> agenticScope.writeState(argName, args[index]));
            }
        }
    }

    private DefaultAgenticScope currentAgenticScope(AgenticScopeRegistry registry, Method method, Object[] args) {
        if (agenticScope != null) {
            return agenticScope;
        }

        Object memoryId = memoryId(method, args);
        DefaultAgenticScope newAgenticScope = memoryId != null ? getOrCreateAgenticScope(registry, memoryId) : createEphemeralAgenticScope(registry);
        return newAgenticScope.withErrorHandler(errorHandler);
    }

    private DefaultAgenticScope createEphemeralAgenticScope(AgenticScopeRegistry registry) {
        DefaultAgenticScope agenticScope = registry.createEphemeralAgenticScope();
        afterAgenticScopeCreated(agentListener, agenticScope);
        return agenticScope;
    }

    private DefaultAgenticScope getOrCreateAgenticScope(AgenticScopeRegistry registry, Object memoryId) {
        DefaultAgenticScope agenticScope = registry.get(memoryId);
        if (agenticScope == null) {
            agenticScope = registry.create(memoryId);
            afterAgenticScopeCreated(agentListener, agenticScope);
        }
        return agenticScope;
    }

    private Object memoryId(Method method, Object[] args) {
        Parameter[] parameters = method.getParameters();
        for (int i = 0; i < parameters.length; i++) {
            if (parameters[i].getAnnotation(MemoryId.class) != null) {
                return args[i];
            }
        }
        return null;
    }

    private Object accessChatMemory(AgenticScope agenticScope, String methodName, Object memoryId) {
        ChatMemoryAccess chatMemoryAccess = ((ChatMemoryAccessProvider) defaultPlannerInstance).chatMemoryAccess(agenticScope);
        return switch (methodName) {
            case "getChatMemory" -> chatMemoryAccess.getChatMemory(memoryId);
            case "evictChatMemory" -> chatMemoryAccess.evictChatMemory(memoryId);
            default -> throw new UnsupportedOperationException("Unknown method on ChatMemoryAccess class : " + methodName);
        };
    }
}
