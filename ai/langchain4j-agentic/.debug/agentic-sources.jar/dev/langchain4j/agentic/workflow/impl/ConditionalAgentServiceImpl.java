package dev.langchain4j.agentic.workflow.impl;

import static dev.langchain4j.agentic.declarative.DeclarativeUtil.buildAgentFeatures;
import static dev.langchain4j.agentic.declarative.DeclarativeUtil.configureOutput;
import static dev.langchain4j.agentic.internal.AgentUtil.agentsToExecutors;
import static dev.langchain4j.agentic.internal.AgentUtil.validateAgentClass;

import dev.langchain4j.agentic.UntypedAgent;
import dev.langchain4j.agentic.internal.AbstractServiceBuilder;
import dev.langchain4j.agentic.internal.AgentExecutor;
import dev.langchain4j.agentic.planner.AgentInstance;
import dev.langchain4j.agentic.scope.AgenticScope;
import dev.langchain4j.agentic.workflow.ConditionalAgent;
import dev.langchain4j.agentic.workflow.ConditionalAgentService;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.function.Predicate;

public class ConditionalAgentServiceImpl<T> extends AbstractServiceBuilder<T, ConditionalAgentService<T>>
        implements ConditionalAgentService<T> {

    protected final List<ConditionalAgent> conditionalAgents = new ArrayList<>();

    public ConditionalAgentServiceImpl(Class<T> agentServiceClass, Method agenticMethod) {
        super(agentServiceClass, agenticMethod);
        configureConditional(agentServiceClass);
    }

    @Override
    public T build() {
        return build(() -> new ConditionalPlanner(conditionalAgents));
    }

    public static ConditionalAgentServiceImpl<UntypedAgent> builder() {
        return new ConditionalAgentServiceImpl<>(UntypedAgent.class, null);
    }

    public static <T> ConditionalAgentServiceImpl<T> builder(Class<T> agentServiceClass) {
        return new ConditionalAgentServiceImpl<>(
                agentServiceClass,
                validateAgentClass(
                        agentServiceClass, false, dev.langchain4j.agentic.declarative.ConditionalAgent.class));
    }

    @Override
    public ConditionalAgentServiceImpl<T> subAgents(Object... agents) {
        return subAgents(agenticScope -> true, agents);
    }

    @Override
    public ConditionalAgentServiceImpl<T> subAgents(Predicate<AgenticScope> condition, Object... agents) {
        return subAgents("<unknown>", condition, agentsToExecutors(List.of(agents)));
    }

    @Override
    public ConditionalAgentServiceImpl<T> subAgents(
            String conditionDescription, Predicate<AgenticScope> condition, Object... agents) {
        return subAgents(conditionDescription, condition, agentsToExecutors(List.of(agents)));
    }

    @Override
    public ConditionalAgentServiceImpl<T> subAgents(Collection<?> agents) {
        return subAgents(agenticScope -> true, agentsToExecutors(agents));
    }

    @Override
    public ConditionalAgentServiceImpl<T> subAgents(
            Predicate<AgenticScope> condition, List<AgentExecutor> agentExecutors) {
        return subAgents("<unknown>", condition, agentExecutors);
    }

    @Override
    public ConditionalAgentServiceImpl<T> subAgents(
            String conditionDescription, Predicate<AgenticScope> condition, List<AgentExecutor> agentExecutors) {
        super.subAgents(agentExecutors);
        conditionalAgents.add(new ConditionalAgent(
                conditionDescription,
                condition,
                agentExecutors.stream().map(AgentInstance.class::cast).toList()));
        return this;
    }

    @Override
    public ConditionalAgentServiceImpl<T> subAgent(Predicate<AgenticScope> condition, AgentExecutor agentExecutor) {
        return subAgents(condition, List.of(agentExecutor));
    }

    @Override
    public ConditionalAgentServiceImpl<T> subAgent(
            String conditionDescription, Predicate<AgenticScope> condition, AgentExecutor agentExecutor) {
        return subAgents(conditionDescription, condition, List.of(agentExecutor));
    }

    @Override
    public String serviceType() {
        return "Conditional";
    }

    private void configureConditional(Class<T> agentServiceClass) {
        configureOutput(agentServiceClass, this);
        buildAgentFeatures(agentServiceClass, this);
    }
}
