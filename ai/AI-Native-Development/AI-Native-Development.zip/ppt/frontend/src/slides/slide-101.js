window.slideDataMap.set(101, `
  <div class="w-[1440px] h-[810px] relative overflow-hidden bg-white" style="font-family:'Noto Sans SC',sans-serif;">
    <div class="absolute top-0 left-0 w-full h-1" style="background:#2563EB;"></div>
    <div class="absolute top-20 right-24 w-24 h-24 border-t border-r" style="border-color:#E2E8F0;"></div>

    <div class="relative z-10 px-16 pt-12">
      <div class="flex items-center gap-3">
        <span class="px-3 py-1 rounded text-[13px] font-semibold" style="background:#EFF6FF;color:#2563EB;">第 1 章 · 架构图</span>
        <span class="text-[13px]" style="color:#64748B;">Python AI 生态概览</span>
      </div>
      <h2 class="text-[34px] font-bold mt-3" style="color:#0F172A;font-family:'Montserrat','Noto Sans SC',sans-serif;">Python AI 生态全景</h2>
    </div>

    <div class="px-16 mt-3 flex items-center justify-center" style="height:600px;">
      <img src="/assets/images/diagram-01_python_ai_ecosystem.png" alt="Python AI 生态全景" style="max-width:96%;max-height:600px;object-fit:contain;border:1px solid #E2E8F0;border-radius:12px;background:#FFFFFF;box-shadow:0 1px 3px rgba(15,23,42,0.08);" />
    </div>

    <div class="px-16 mt-1">
      <p class="text-[15px] leading-relaxed" style="color:#475569;">五层技术栈：从 Web 框架到工具协议，对应 Java 工程师熟悉的组件</p>
    </div>

    <div class="absolute bottom-10 right-24 text-[14px]" style="color:#94A3B8;">Python AI Agent 快速扫盲 · 6 / 41</div>
  </div>
`);
