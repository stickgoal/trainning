package me.maizz.shardingjdbcapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShardingJdbcAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
