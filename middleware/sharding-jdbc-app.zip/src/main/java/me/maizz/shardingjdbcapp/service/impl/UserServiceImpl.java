package me.maizz.shardingjdbcapp.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import me.maizz.shardingjdbcapp.model.User;
import me.maizz.shardingjdbcapp.mapper.UserMapper;
import me.maizz.shardingjdbcapp.service.UserService;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {
}
