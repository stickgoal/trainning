package me.maizz.shardingjdbcapp.service;

import com.baomidou.mybatisplus.extension.service.IService;
import me.maizz.shardingjdbcapp.model.User;

/**
 * 用户服务：插入、查询（分库）
 */
public interface UserService extends IService<User> {
}
