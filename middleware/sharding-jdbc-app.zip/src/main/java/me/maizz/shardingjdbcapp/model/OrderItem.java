package me.maizz.shardingjdbcapp.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 订单条目表（分表：ds0 下 t_order_item_1、t_order_item_2，按 order_id 分表，与 t_order 绑定）
 */
@Data
@TableName("t_order_item")
public class OrderItem {

    @TableId(value = "order_item_id", type = IdType.AUTO)
    private Long orderItemId;

    /** 订单ID，分表分片键（与 t_order 绑定） */
    private Long orderId;

    /** 商品ID */
    private Long productId;

    /** 商品数量 */
    private Integer quantity;

    /** 商品单价 */
    private BigDecimal price;

    private LocalDateTime createTime;
    private LocalDateTime updateTime;
}

