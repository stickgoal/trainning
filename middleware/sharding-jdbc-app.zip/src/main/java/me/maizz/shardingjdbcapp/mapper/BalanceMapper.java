package me.maizz.shardingjdbcapp.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import me.maizz.shardingjdbcapp.model.Balance;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BalanceMapper extends BaseMapper<Balance> {
}
