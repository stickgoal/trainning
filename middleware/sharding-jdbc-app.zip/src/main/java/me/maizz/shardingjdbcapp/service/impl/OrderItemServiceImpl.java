package me.maizz.shardingjdbcapp.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import me.maizz.shardingjdbcapp.mapper.OrderItemMapper;
import me.maizz.shardingjdbcapp.model.OrderItem;
import me.maizz.shardingjdbcapp.service.OrderItemService;
import org.springframework.stereotype.Service;

@Service
public class OrderItemServiceImpl extends ServiceImpl<OrderItemMapper, OrderItem> implements OrderItemService {
}

