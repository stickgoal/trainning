package me.maizz.shardingjdbcapp.dto.log;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * 日志出参 VO
 */
@Data
public class LogVO {

    /**
     * 日志ID
     */
    private Long logId;

    /**
     * 操作用户ID
     */
    private Long userId;

    /**
     * 用户名（关联查询）
     */
    private String username;

    /**
     * 操作类型
     */
    private String operationType;

    /**
     * 操作描述
     */
    private String description;

    /**
     * 请求方法
     */
    private String requestMethod;

    /**
     * 请求参数
     */
    private String requestParams;

    /**
     * 响应结果
     */
    private String responseResult;

    /**
     * 操作IP地址
     */
    private String ipAddress;

    /**
     * 用户代理
     */
    private String userAgent;

    /**
     * 操作状态（0：失败，1：成功）
     */
    private Integer status;

    /**
     * 状态描述
     */
    private String statusDesc;

    /**
     * 错误信息
     */
    private String errorMessage;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 更新时间
     */
    private LocalDateTime updateTime;
}
