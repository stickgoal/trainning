package me.maizz.shardingjdbcapp.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import me.maizz.shardingjdbcapp.mapper.UserLevelMapper;
import me.maizz.shardingjdbcapp.model.UserLevel;
import me.maizz.shardingjdbcapp.service.UserLevelService;
import org.springframework.stereotype.Service;

@Service
public class UserLevelServiceImpl extends ServiceImpl<UserLevelMapper, UserLevel> implements UserLevelService {
}

