package me.maizz.shardingjdbcapp.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import me.maizz.shardingjdbcapp.model.User;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserMapper extends BaseMapper<User> {
}
