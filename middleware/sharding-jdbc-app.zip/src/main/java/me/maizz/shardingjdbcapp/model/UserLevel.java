package me.maizz.shardingjdbcapp.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 用户等级表（广播表：ds0/ds1 都有，数据一致）
 */
@Data
@TableName("user_level")
public class UserLevel {

    @TableId(value = "level_id", type = IdType.INPUT)
    private Long levelId;

    private String levelName;

    private Integer minPoints;

    private Integer maxPoints;

    private BigDecimal discountRate;

    private Integer status;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;
}

