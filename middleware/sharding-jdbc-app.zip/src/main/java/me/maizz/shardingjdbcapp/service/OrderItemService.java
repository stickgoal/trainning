package me.maizz.shardingjdbcapp.service;

import com.baomidou.mybatisplus.extension.service.IService;
import me.maizz.shardingjdbcapp.model.OrderItem;

/**
 * 订单条目服务：插入、查询（分表）
 */
public interface OrderItemService extends IService<OrderItem> {
}

