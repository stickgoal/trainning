package me.maizz.shardingjdbcapp.service;

import com.baomidou.mybatisplus.extension.service.IService;
import me.maizz.shardingjdbcapp.dto.log.LogForm;
import me.maizz.shardingjdbcapp.dto.log.LogVO;
import me.maizz.shardingjdbcapp.model.Log;

import java.util.List;

/**
 * 日志服务：插入、查询（ds1单表）
 */
public interface LogService extends IService<Log> {
    
    /**
     * 创建日志记录
     */
    boolean createLog(LogForm logForm);
    
    /**
     * 根据用户ID查询日志列表
     */
    List<LogVO> getLogsByUserId(Long userId);
    
    /**
     * 根据操作类型查询日志列表
     */
    List<LogVO> getLogsByOperationType(String operationType);
    
    /**
     * 分页查询日志列表
     */
    List<LogVO> getLogList(int page, int size);
}
