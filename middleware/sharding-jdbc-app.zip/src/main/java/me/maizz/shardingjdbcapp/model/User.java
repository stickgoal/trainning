package me.maizz.shardingjdbcapp.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 用户表（分库：ds0 / ds1 各一张 user 表，按 user_id 分库）
 */
@Data
@TableName("user")
public class User {

    @TableId(value = "user_id", type = IdType.AUTO)
    /** 用户ID，分库分片键，由 Sharding-JDBC 生成 */
    private Long userId;
    private String username;
    private String phone;
    /** 用户等级ID（关联广播表 t_user_level） */
    private Long levelId;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;
}
