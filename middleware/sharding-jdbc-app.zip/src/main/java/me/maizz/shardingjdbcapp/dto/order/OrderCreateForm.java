package me.maizz.shardingjdbcapp.dto.order;

import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

/**
 * 创建订单及条目的表单入参
 */
@Data
public class OrderCreateForm {

    /**
     * 用户ID
     */
    private Long userId;

    /**
     * 订单总金额
     */
    private BigDecimal amount;

    /**
     * 订单状态
     */
    private String status;

    /**
     * 订单条目列表
     */
    private List<OrderItemForm> items;
}

