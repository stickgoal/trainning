package me.maizz.shardingjdbcapp.service;

import com.baomidou.mybatisplus.extension.service.IService;
import me.maizz.shardingjdbcapp.model.Balance;

/**
 * 用户余额服务：插入、查询（分表）
 */
public interface BalanceService extends IService<Balance> {
}
