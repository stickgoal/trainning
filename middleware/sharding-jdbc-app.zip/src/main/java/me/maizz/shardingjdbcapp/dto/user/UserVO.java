package me.maizz.shardingjdbcapp.dto.user;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 用户出参 VO
 */
@Data
public class UserVO {

    /**
     * 用户ID
     */
    private Long userId;

    /**
     * 用户名
     */
    private String username;

    /**
     * 手机号
     */
    private String phone;

    /**
     * 用户等级ID（关联广播表 t_user_level）
     */
    private Long levelId;

    /**
     * 用户等级名称（来自广播表）
     */
    private String levelName;

    /**
     * 折扣系数（来自广播表）
     */
    private BigDecimal discountRate;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;
}

