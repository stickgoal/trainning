package me.maizz.shardingjdbcapp.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 用户余额表（分表：ds0 下 balance_1、balance_2、balance_3，按 user_id 分表）
 */
@Data
@TableName("balance")
public class Balance {

    @TableId(type = IdType.AUTO)
    private Long balanceId;
    /** 用户ID，分表分片键 */
    private Long userId;
    private BigDecimal balance;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;
}
