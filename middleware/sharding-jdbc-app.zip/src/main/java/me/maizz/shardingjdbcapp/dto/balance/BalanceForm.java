package me.maizz.shardingjdbcapp.dto.balance;

import lombok.Data;

import java.math.BigDecimal;

/**
 * 余额新增/更新表单入参
 */
@Data
public class BalanceForm {

    /**
     * 余额ID，更新时必传，新增时不传
     */
    private Long balanceId;

    /**
     * 用户ID（分片键）
     */
    private Long userId;

    /**
     * 余额
     */
    private BigDecimal balance;
}

