package me.maizz.shardingjdbcapp.controller;

import cn.hutool.core.lang.generator.SnowflakeGenerator;
import me.maizz.shardingjdbcapp.config.SnowFlakeHelper;
import me.maizz.shardingjdbcapp.model.UserLevel;
import me.maizz.shardingjdbcapp.service.UserLevelService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 用户等级接口（广播表）
 */
@RestController
@RequestMapping("/userLevel")
public class UserLevelController {

    private static final Logger log = LoggerFactory.getLogger(UserLevelController.class);

    private final UserLevelService userLevelService;

    public UserLevelController(UserLevelService userLevelService) {
        this.userLevelService = userLevelService;
    }

    @PostMapping("/add")
    public UserLevel add(@RequestBody UserLevel level) {
        log.info("UserLevelController.add - level: {}", level);
        level.setLevelId(SnowFlakeHelper.nextId());
        userLevelService.save(level);
        return level;
    }

    @GetMapping("/get/{id}")
    public UserLevel getById(@PathVariable Long id) {
        log.info("UserLevelController.getById - id: {}", id);
        return userLevelService.getById(id);
    }

    @GetMapping("/list")
    public List<UserLevel> list() {
        log.info("UserLevelController.list called");
        return userLevelService.list();
    }
}

