package me.maizz.shardingjdbcapp.dto.order;

import lombok.Data;

import java.math.BigDecimal;

/**
 * 订单条目表单入参
 */
@Data
public class OrderItemForm {

    /**
     * 商品ID
     */
    private Long productId;

    /**
     * 商品数量
     */
    private Integer quantity;

    /**
     * 商品单价
     */
    private BigDecimal price;
}

