package me.maizz.shardingjdbcapp.dto.balance;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 余额出参 VO
 */
@Data
public class BalanceVO {

    private Long balanceId;

    private Long userId;

    private BigDecimal balance;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;
}

