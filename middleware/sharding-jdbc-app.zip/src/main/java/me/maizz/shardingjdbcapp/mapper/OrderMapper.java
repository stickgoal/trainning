package me.maizz.shardingjdbcapp.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import me.maizz.shardingjdbcapp.model.Order;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface OrderMapper extends BaseMapper<Order> {
}

