package me.maizz.shardingjdbcapp.service;

import com.baomidou.mybatisplus.extension.service.IService;
import me.maizz.shardingjdbcapp.model.Order;

/**
 * 订单服务：插入、查询（分表，含订单条目信息）
 */
public interface OrderService extends IService<Order> {

    /**
     * 创建订单及其条目
     */
    Order createOrderWithItems(Order order);

    /**
     * 按订单ID查询订单及其条目
     */
    Order getOrderWithItems(Long orderId);
}

