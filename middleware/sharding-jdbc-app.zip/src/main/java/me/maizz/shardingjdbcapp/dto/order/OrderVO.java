package me.maizz.shardingjdbcapp.dto.order;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 订单出参 VO
 */
@Data
public class OrderVO {

    private Long orderId;

    private Long userId;

    private BigDecimal amount;

    private String status;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;

    private List<OrderItemVO> items;
}

