package me.maizz.shardingjdbcapp.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import me.maizz.shardingjdbcapp.dto.log.LogForm;
import me.maizz.shardingjdbcapp.dto.log.LogVO;
import me.maizz.shardingjdbcapp.mapper.LogMapper;
import me.maizz.shardingjdbcapp.model.Log;
import me.maizz.shardingjdbcapp.service.LogService;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class LogServiceImpl extends ServiceImpl<LogMapper, Log> implements LogService {

    @Override
    public boolean createLog(LogForm logForm) {
        Log log = new Log();
        BeanUtils.copyProperties(logForm, log);
        log.setCreateTime(LocalDateTime.now());
        log.setUpdateTime(LocalDateTime.now());
        return save(log);
    }

    @Override
    public List<LogVO> getLogsByUserId(Long userId) {
        LambdaQueryWrapper<Log> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(Log::getUserId, userId)
                   .orderByDesc(Log::getCreateTime);
        List<Log> logs = list(queryWrapper);
        return logs.stream().map(this::convertToVO).collect(Collectors.toList());
    }

    @Override
    public List<LogVO> getLogsByOperationType(String operationType) {
        LambdaQueryWrapper<Log> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(Log::getOperationType, operationType)
                   .orderByDesc(Log::getCreateTime);
        List<Log> logs = list(queryWrapper);
        return logs.stream().map(this::convertToVO).collect(Collectors.toList());
    }

    @Override
    public List<LogVO> getLogList(int page, int size) {
        Page<Log> pageParam = new Page<>(page, size);
        LambdaQueryWrapper<Log> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.orderByDesc(Log::getCreateTime);
        Page<Log> logPage = page(pageParam, queryWrapper);
        return logPage.getRecords().stream().map(this::convertToVO).collect(Collectors.toList());
    }

    private LogVO convertToVO(Log log) {
        LogVO logVO = new LogVO();
        BeanUtils.copyProperties(log, logVO);
        
        // 设置状态描述
        if (log.getStatus() != null) {
            logVO.setStatusDesc(log.getStatus() == 1 ? "成功" : "失败");
        }
        
        return logVO;
    }
}
