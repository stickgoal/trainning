package me.maizz.shardingjdbcapp.config;

import cn.hutool.core.lang.generator.SnowflakeGenerator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class SnowFlakeHelper {
    private static final Logger logger = LoggerFactory.getLogger(SnowFlakeHelper.class);
    public static final long DATA_CENTER_ID = 1L;

    public static Long nextId() {
        return new SnowflakeGenerator(generateWorkerId(), DATA_CENTER_ID).next();
    }

    public static long generateWorkerId() {
        return generateWorkerId(31); // 默认 5 位 workerId
    }
    /**
     * 根据 IP 地址生成 workerId
     * @param maxWorkerId 最大值（如果是 5 位则为 31，10 位则为 1023）
     * @return 映射后的 workerId
     */
    public static long generateWorkerId(long maxWorkerId) {
        try {
            InetAddress ip = InetAddress.getLocalHost();
            String hostAddress = ip.getHostAddress();
            logger.info("Local IP Address: {}", hostAddress);
            // 将 IP 字符串转换为数字总和或 HashCode
            // 方式 A: 使用 HashCode (简单但易冲突)
            // long workerId = Math.abs(hostAddress.hashCode()) % (maxWorkerId + 1);

            // 方式 B: 基于 IP 的每个字节进行加权计算（相对分散）
            byte[] ipBytes = ip.getAddress();
            long workerId = 0;
            for (byte b : ipBytes) {
                workerId += (b & 0xFF); // 取无符号位
                logger.info("Processing byte: {}, current workerId: {}", b, workerId);
            }

            long result = workerId % (maxWorkerId + 1);
            logger.info("Generated Worker ID: {}", result);
            return result;
        } catch (UnknownHostException e) {
            logger.error("Failed to get local IP address, generating random worker ID", e);
            // 如果获取不到 IP，可以考虑生成一个随机数作为兜底
            return (long) (Math.random() * maxWorkerId);
        }
    }

    public static void main(String[] args) {
        long maxWorkerId = 31;
        long id = generateWorkerId(maxWorkerId);
        System.out.println("Generated Worker ID: " + id);
    }
}
