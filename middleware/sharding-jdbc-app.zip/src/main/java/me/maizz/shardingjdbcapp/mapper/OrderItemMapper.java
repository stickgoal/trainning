package me.maizz.shardingjdbcapp.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import me.maizz.shardingjdbcapp.model.OrderItem;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface OrderItemMapper extends BaseMapper<OrderItem> {
}

