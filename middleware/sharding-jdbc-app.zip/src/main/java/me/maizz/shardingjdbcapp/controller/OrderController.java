package me.maizz.shardingjdbcapp.controller;

import me.maizz.shardingjdbcapp.dto.order.OrderCreateForm;
import me.maizz.shardingjdbcapp.dto.order.OrderItemForm;
import me.maizz.shardingjdbcapp.dto.order.OrderItemVO;
import me.maizz.shardingjdbcapp.dto.order.OrderVO;
import me.maizz.shardingjdbcapp.model.Order;
import me.maizz.shardingjdbcapp.model.OrderItem;
import me.maizz.shardingjdbcapp.service.OrderService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 订单接口：创建订单及条目、查询订单及条目（分表 ds0.t_order_1/2 & t_order_item_1/2）
 */
@RestController
@RequestMapping("/order")
public class OrderController {

    private static final Logger log = LoggerFactory.getLogger(OrderController.class);

    private final OrderService orderService;

    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    /**
     * 创建订单及其条目
     */
    @PostMapping("/create")
    public OrderVO create(@RequestBody OrderCreateForm form) {
        log.info("OrderController.create - form: {}", form);

        Order order = new Order();
        order.setUserId(form.getUserId());
        order.setAmount(form.getAmount());
        order.setStatus(form.getStatus());

        List<OrderItemForm> itemForms = form.getItems();
        if (itemForms != null && !itemForms.isEmpty()) {
            List<OrderItem> items = itemForms.stream().map(this::toOrderItem).collect(Collectors.toList());
            order.setItems(items);
        }

        Order created = orderService.createOrderWithItems(order);
        return toVO(created);
    }

    /**
     * 按订单ID查询订单及其条目（按分片键 order_id 查询）
     */
    @GetMapping("/get/{orderId}")
    public OrderVO get(@PathVariable Long orderId) {
        log.info("OrderController.get - orderId: {}", orderId);
        Order order = orderService.getOrderWithItems(orderId);
        return toVO(order);
    }

    private OrderItem toOrderItem(OrderItemForm form) {
        OrderItem item = new OrderItem();
        item.setProductId(form.getProductId());
        item.setQuantity(form.getQuantity());
        item.setPrice(form.getPrice());
        return item;
    }

    private OrderVO toVO(Order order) {
        if (order == null) {
            return null;
        }
        OrderVO vo = new OrderVO();
        vo.setOrderId(order.getOrderId());
        vo.setUserId(order.getUserId());
        vo.setAmount(order.getAmount());
        vo.setStatus(order.getStatus());
        vo.setCreateTime(order.getCreateTime());
        vo.setUpdateTime(order.getUpdateTime());

        List<OrderItem> items = order.getItems();
        if (items != null && !items.isEmpty()) {
            List<OrderItemVO> itemVOS = items.stream().map(this::toItemVO).collect(Collectors.toList());
            vo.setItems(itemVOS);
        }
        return vo;
    }

    private OrderItemVO toItemVO(OrderItem item) {
        OrderItemVO vo = new OrderItemVO();
        vo.setOrderItemId(item.getOrderItemId());
        vo.setOrderId(item.getOrderId());
        vo.setProductId(item.getProductId());
        vo.setQuantity(item.getQuantity());
        vo.setPrice(item.getPrice());
        vo.setCreateTime(item.getCreateTime());
        vo.setUpdateTime(item.getUpdateTime());
        return vo;
    }
}
