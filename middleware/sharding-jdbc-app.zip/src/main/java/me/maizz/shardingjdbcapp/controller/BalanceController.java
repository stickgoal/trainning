package me.maizz.shardingjdbcapp.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import me.maizz.shardingjdbcapp.dto.balance.BalanceForm;
import me.maizz.shardingjdbcapp.dto.balance.BalanceVO;
import me.maizz.shardingjdbcapp.model.Balance;
import me.maizz.shardingjdbcapp.service.BalanceService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 用户余额接口：插入、查询（分表 ds0.balance_1/2/3）
 */
@RestController
@RequestMapping("/balance")
public class BalanceController {

    private static final Logger log = LoggerFactory.getLogger(BalanceController.class);

    private final BalanceService balanceService;

    public BalanceController(BalanceService balanceService) {
        this.balanceService = balanceService;
    }

    /**
     * 新增/更新余额（按 user_id 分表到 balance_1/2/3）
     *
     * balanceId 为空表示新增，不为空表示更新
     */
    @PostMapping("/add")
    public BalanceVO add(@RequestBody BalanceForm form) {
        log.info("BalanceController.add - form: {}", form);

        Balance balance = new Balance();
        balance.setUserId(form.getUserId());
        balance.setBalance(form.getBalance());

        balanceService.save(balance);

        return toVO(balanceService.getById(balance.getBalanceId()));
    }

    /**
     * 按主键 id 查询
     */
    @GetMapping("/get/{id}")
    public BalanceVO getById(@PathVariable Long id) {
        log.info("BalanceController.getById - id: {}", id);
        return toVO(balanceService.getById(id));
    }

    /**
     * 按 user_id 查询余额（分片键，单表查询）
     */
    @GetMapping("/getByUserId/{userId}")
    public BalanceVO getByUserId(@PathVariable Long userId) {
        log.info("BalanceController.getByUserId - userId: {}", userId);
        Balance balance = balanceService.lambdaQuery()
                .eq(Balance::getUserId, userId)
                .one();
        return toVO(balance);
    }

    /**
     * 查询所有余额记录（会扫描 ds0 下 balance_1、balance_2、balance_3）
     */
    @GetMapping("/list")
    public List<BalanceVO> list() {
        log.info("BalanceController.list called");
        return balanceService.list()
                .stream()
                .map(this::toVO)
                .collect(Collectors.toList());
    }

    /**
     * 分页查询余额记录
     */
    @GetMapping("/page")
    public Page<BalanceVO> page(@RequestParam(defaultValue = "1") long page,
                                @RequestParam(defaultValue = "10") long size) {
        log.info("BalanceController.page - page: {}, size: {}", page, size);
        Page<Balance> p = new Page<>(page, size);
        Page<Balance> resultPage = balanceService.page(p);

        Page<BalanceVO> voPage = new Page<>(resultPage.getCurrent(), resultPage.getSize(), resultPage.getTotal());
        voPage.setRecords(resultPage.getRecords()
                .stream()
                .map(this::toVO)
                .collect(Collectors.toList()));
        return voPage;
    }

    private BalanceVO toVO(Balance balance) {
        if (balance == null) {
            return null;
        }
        BalanceVO vo = new BalanceVO();
        vo.setBalanceId(balance.getBalanceId());
        vo.setUserId(balance.getUserId());
        vo.setBalance(balance.getBalance());
        vo.setCreateTime(balance.getCreateTime());
        vo.setUpdateTime(balance.getUpdateTime());
        return vo;
    }
}
