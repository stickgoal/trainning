package me.maizz.shardingjdbcapp.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import me.maizz.shardingjdbcapp.model.UserLevel;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserLevelMapper extends BaseMapper<UserLevel> {
}

