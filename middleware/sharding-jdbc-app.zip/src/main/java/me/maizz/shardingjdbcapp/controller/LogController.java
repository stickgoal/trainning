package me.maizz.shardingjdbcapp.controller;

import me.maizz.shardingjdbcapp.dto.log.LogForm;
import me.maizz.shardingjdbcapp.dto.log.LogVO;
import me.maizz.shardingjdbcapp.service.LogService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 日志接口：插入、查询（ds1单表）
 */
@RestController
@RequestMapping("/log")
public class LogController {

    private static final Logger log = LoggerFactory.getLogger(LogController.class);

    private final LogService logService;

    public LogController(LogService logService) {
        this.logService = logService;
    }

    /**
     * 新增日志记录
     */
    @PostMapping("/add")
    public boolean add(@RequestBody LogForm form) {
        log.info("LogController.add - form: {}", form);
        return logService.createLog(form);
    }

    /**
     * 按主键ID查询日志
     */
    @GetMapping("/get/{id}")
    public LogVO getById(@PathVariable Long id) {
        log.info("LogController.getById - id: {}", id);
        return logService.lambdaQuery()
                .eq(me.maizz.shardingjdbcapp.model.Log::getLogId, id)
                .oneOpt()
                .map(this::convertToVO)
                .orElse(null);
    }

    /**
     * 按用户ID查询日志列表
     */
    @GetMapping("/getByUserId/{userId}")
    public List<LogVO> getByUserId(@PathVariable Long userId) {
        log.info("LogController.getByUserId - userId: {}", userId);
        return logService.getLogsByUserId(userId);
    }

    /**
     * 按操作类型查询日志列表
     */
    @GetMapping("/getByOperationType/{operationType}")
    public List<LogVO> getByOperationType(@PathVariable String operationType) {
        log.info("LogController.getByOperationType - operationType: {}", operationType);
        return logService.getLogsByOperationType(operationType);
    }

    /**
     * 查询所有日志列表
     */
    @GetMapping("/list")
    public List<LogVO> list() {
        log.info("LogController.list called");
        return logService.lambdaQuery()
                .orderByDesc(me.maizz.shardingjdbcapp.model.Log::getCreateTime)
                .list()
                .stream()
                .map(this::convertToVO)
                .collect(java.util.stream.Collectors.toList());
    }

    /**
     * 分页查询日志列表
     */
    @GetMapping("/page")
    public List<LogVO> page(@RequestParam(defaultValue = "1") int page,
                            @RequestParam(defaultValue = "10") int size) {
        log.info("LogController.page - page: {}, size: {}", page, size);
        return logService.getLogList(page, size);
    }

    private LogVO convertToVO(me.maizz.shardingjdbcapp.model.Log logEntity) {
        if (logEntity == null) {
            return null;
        }
        LogVO vo = new LogVO();
        vo.setLogId(logEntity.getLogId());
        vo.setUserId(logEntity.getUserId());
        vo.setOperationType(logEntity.getOperationType());
        vo.setDescription(logEntity.getDescription());
        vo.setRequestMethod(logEntity.getRequestMethod());
        vo.setRequestParams(logEntity.getRequestParams());
        vo.setResponseResult(logEntity.getResponseResult());
        vo.setIpAddress(logEntity.getIpAddress());
        vo.setUserAgent(logEntity.getUserAgent());
        vo.setStatus(logEntity.getStatus());
        vo.setErrorMessage(logEntity.getErrorMessage());
        vo.setCreateTime(logEntity.getCreateTime());
        vo.setUpdateTime(logEntity.getUpdateTime());

        // 设置状态描述
        if (logEntity.getStatus() != null) {
            vo.setStatusDesc(logEntity.getStatus() == 1 ? "成功" : "失败");
        }

        return vo;
    }
}
