package me.maizz.shardingjdbcapp.dto.log;

import lombok.Data;

/**
 * 日志创建/更新表单入参
 */
@Data
public class LogForm {

    /**
     * 操作用户ID
     */
    private Long userId;

    /**
     * 操作类型
     */
    private String operationType;

    /**
     * 操作描述
     */
    private String description;

    /**
     * 请求方法
     */
    private String requestMethod;

    /**
     * 请求参数
     */
    private String requestParams;

    /**
     * 响应结果
     */
    private String responseResult;

    /**
     * 操作IP地址
     */
    private String ipAddress;

    /**
     * 用户代理
     */
    private String userAgent;

    /**
     * 操作状态（0：失败，1：成功）
     */
    private Integer status;

    /**
     * 错误信息
     */
    private String errorMessage;
}
