package me.maizz.shardingjdbcapp.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 订单表（分表：ds0 下 t_order_1、t_order_2，按 order_id 分表）
 */
@Data
@TableName("t_order")
public class Order {

    @TableId(value = "order_id", type = IdType.AUTO)
    /** 订单ID，分表分片键，由 Sharding-JDBC 生成 */
    private Long orderId;

    /** 用户ID */
    private Long userId;

    /** 订单总金额 */
    private BigDecimal amount;

    /** 订单状态 */
    private String status;

    private LocalDateTime createTime;
    private LocalDateTime updateTime;

    /** 订单条目列表，不参与 ORM 映射 */
    @TableField(exist = false)
    private List<OrderItem> items;
}

