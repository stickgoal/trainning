package me.maizz.shardingjdbcapp.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import me.maizz.shardingjdbcapp.model.Balance;
import me.maizz.shardingjdbcapp.mapper.BalanceMapper;
import me.maizz.shardingjdbcapp.service.BalanceService;
import org.springframework.stereotype.Service;

@Service
public class BalanceServiceImpl extends ServiceImpl<BalanceMapper, Balance> implements BalanceService {
}
