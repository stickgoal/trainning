package me.maizz.shardingjdbcapp;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("me.maizz.shardingjdbcapp.mapper")
public class ShardingJdbcAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(ShardingJdbcAppApplication.class, args);
    }

}
