package me.maizz.shardingjdbcapp.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import me.maizz.shardingjdbcapp.model.Log;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface LogMapper extends BaseMapper<Log> {
}
