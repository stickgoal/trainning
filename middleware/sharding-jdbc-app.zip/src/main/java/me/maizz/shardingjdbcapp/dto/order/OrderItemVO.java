package me.maizz.shardingjdbcapp.dto.order;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 订单条目出参 VO
 */
@Data
public class OrderItemVO {

    private Long orderItemId;

    private Long orderId;

    private Long productId;

    private Integer quantity;

    private BigDecimal price;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;
}

