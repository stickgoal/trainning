package me.maizz.shardingjdbcapp.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import me.maizz.shardingjdbcapp.dto.user.UserForm;
import me.maizz.shardingjdbcapp.dto.user.UserVO;
import me.maizz.shardingjdbcapp.model.User;
import me.maizz.shardingjdbcapp.model.UserLevel;
import me.maizz.shardingjdbcapp.service.UserLevelService;
import me.maizz.shardingjdbcapp.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * 用户接口：插入、查询（分库 ds0/ds1）
 */
@RestController
@RequestMapping("/user")
public class UserController {

    private static final Logger log = LoggerFactory.getLogger(UserController.class);

    private final UserService userService;
    private final UserLevelService userLevelService;

    public UserController(UserService userService, UserLevelService userLevelService) {
        this.userService = userService;
        this.userLevelService = userLevelService;
    }

    /**
     * 新增用户（按 user_id 分库）
     */
    @PostMapping("/add")
    public UserVO add(@RequestBody UserForm form) {
        log.info("UserController.add - form: {}", form);
        User user = new User();
        user.setUsername(form.getUsername());
        user.setPhone(form.getPhone());
        user.setLevelId(form.getLevelId());

        userService.save(user);

        return toVO(user, loadLevelMapByIds(Collections.singleton(user.getLevelId())));
    }

    /**
     * 按主键 id 查询（需带分片键条件时路由更明确，这里演示按 id 查）
     */
    @GetMapping("/get/{id}")
    public UserVO getById(@PathVariable Long id) {
        log.info("UserController.getById - id: {}", id);
        User user = userService.getById(id);
        return toVO(user, loadLevelMapByIds(Collections.singleton(user == null ? null : user.getLevelId())));
    }

    /**
     * 按 user_id 查询（分片键，单库查询）
     */
    @GetMapping("/getByUserId/{userId}")
    public UserVO getByUserId(@PathVariable Long userId) {
        log.info("UserController.getByUserId - userId: {}", userId);
        User user = userService.lambdaQuery()
                .eq(User::getUserId, userId)
                .one();
        return toVO(user, loadLevelMapByIds(Collections.singleton(user == null ? null : user.getLevelId())));
    }

    /**
     * 查询所有用户（会扫描 ds0、ds1 两张 user 表）
     */
    @GetMapping("/list")
    public List<UserVO> list() {
        log.info("UserController.list called");
        List<User> users = userService.list();
        Map<Long, UserLevel> levelMap = loadLevelMapByIds(users.stream().map(User::getLevelId).collect(Collectors.toSet()));
        return users.stream()
                .map(u -> toVO(u, levelMap))
                .collect(Collectors.toList());
    }

    /**
     * 分页查询用户
     */
    @GetMapping("/page")
    public Page<UserVO> page(@RequestParam(defaultValue = "1") long page,
                             @RequestParam(defaultValue = "10") long size) {
        log.info("UserController.page - page: {}, size: {}", page, size);
        Page<User> p = new Page<>(page, size);
        Page<User> resultPage = userService.page(p);

        Map<Long, UserLevel> levelMap = loadLevelMapByIds(resultPage.getRecords().stream().map(User::getLevelId).collect(Collectors.toSet()));
        Page<UserVO> voPage = new Page<>(resultPage.getCurrent(), resultPage.getSize(), resultPage.getTotal());
        voPage.setRecords(resultPage.getRecords()
                .stream()
                .map(u -> toVO(u, levelMap))
                .collect(Collectors.toList()));
        return voPage;
    }

    private Map<Long, UserLevel> loadLevelMapByIds(Set<Long> levelIds) {
        if (levelIds == null) {
            return Collections.emptyMap();
        }
        Set<Long> ids = levelIds.stream().filter(id -> id != null && id > 0).collect(Collectors.toSet());
        if (ids.isEmpty()) {
            return Collections.emptyMap();
        }
        return userLevelService.listByIds(ids).stream()
                .collect(Collectors.toMap(UserLevel::getLevelId, Function.identity(), (a, b) -> a));
    }

    private UserVO toVO(User user, Map<Long, UserLevel> levelMap) {
        if (user == null) {
            return null;
        }
        UserVO vo = new UserVO();
        vo.setUserId(user.getUserId());
        vo.setUsername(user.getUsername());
        vo.setPhone(user.getPhone());
        vo.setLevelId(user.getLevelId());
        vo.setCreateTime(user.getCreateTime());
        vo.setUpdateTime(user.getUpdateTime());

        if (levelMap != null && user.getLevelId() != null) {
            UserLevel level = levelMap.get(user.getLevelId());
            if (level != null) {
                vo.setLevelName(level.getLevelName());
                vo.setDiscountRate(level.getDiscountRate());
            }
        }
        return vo;
    }
}
