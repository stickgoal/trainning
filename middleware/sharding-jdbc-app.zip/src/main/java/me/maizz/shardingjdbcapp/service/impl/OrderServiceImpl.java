package me.maizz.shardingjdbcapp.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import me.maizz.shardingjdbcapp.mapper.OrderMapper;
import me.maizz.shardingjdbcapp.model.Order;
import me.maizz.shardingjdbcapp.model.OrderItem;
import me.maizz.shardingjdbcapp.service.OrderItemService;
import me.maizz.shardingjdbcapp.service.OrderService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Service
public class OrderServiceImpl extends ServiceImpl<OrderMapper, Order> implements OrderService {

    private final OrderItemService orderItemService;

    public OrderServiceImpl(OrderItemService orderItemService) {
        this.orderItemService = orderItemService;
    }

    /**
     * 创建订单及其条目（保证在同一事务中）
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public Order createOrderWithItems(Order order) {
        List<OrderItem> items = order.getItems();

        // 如果未传入总金额，则根据条目计算
        if (order.getAmount() == null && items != null && !items.isEmpty()) {
            BigDecimal total = items.stream()
                    .map(i -> i.getPrice().multiply(BigDecimal.valueOf(i.getQuantity())))
                    .reduce(BigDecimal.ZERO, BigDecimal::add);
            order.setAmount(total);
        }

        // 保存订单
        this.save(order);

        // 保存订单条目
        if (items != null && !items.isEmpty()) {
            for (OrderItem item : items) {
                // 绑定订单ID（分片键）
                item.setOrderId(order.getOrderId());
            }
            orderItemService.saveBatch(items);
        }

        order.setItems(items);
        return order;
    }

    /**
     * 按订单ID查询订单及其条目
     */
    @Override
    public Order getOrderWithItems(Long orderId) {
        Order order = this.lambdaQuery()
                .eq(Order::getOrderId, orderId)
                .one();
        if (order == null) {
            return null;
        }
        List<OrderItem> items = orderItemService.lambdaQuery()
                .eq(OrderItem::getOrderId, orderId)
                .list();
        order.setItems(items);
        return order;
    }
}

