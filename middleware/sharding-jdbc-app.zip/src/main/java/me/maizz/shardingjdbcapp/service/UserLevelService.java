package me.maizz.shardingjdbcapp.service;

import com.baomidou.mybatisplus.extension.service.IService;
import me.maizz.shardingjdbcapp.model.UserLevel;

/**
 * 用户等级服务（广播表）
 */
public interface UserLevelService extends IService<UserLevel> {
}

