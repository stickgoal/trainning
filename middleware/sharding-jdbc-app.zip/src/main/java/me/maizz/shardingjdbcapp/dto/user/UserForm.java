package me.maizz.shardingjdbcapp.dto.user;

import lombok.Data;

/**
 * 用户创建/更新表单入参
 */
@Data
public class UserForm {

    /**
     * 用户名
     */
    private String username;

    /**
     * 手机号
     */
    private String phone;

    /**
     * 用户等级ID（关联广播表 t_user_level）
     */
    private Long levelId;
}

