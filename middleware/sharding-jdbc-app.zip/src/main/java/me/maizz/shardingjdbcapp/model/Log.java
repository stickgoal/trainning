package me.maizz.shardingjdbcapp.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 日志表（单表：ds1.log）
 */
@Data
@TableName("log")
public class Log {

    @TableId(value = "log_id", type = IdType.AUTO)
    private Long logId;
    
    /** 操作用户ID */
    private Long userId;
    
    /** 操作类型 */
    private String operationType;
    
    /** 操作描述 */
    private String description;
    
    /** 请求方法 */
    private String requestMethod;
    
    /** 请求参数 */
    private String requestParams;
    
    /** 响应结果 */
    private String responseResult;
    
    /** 操作IP地址 */
    private String ipAddress;
    
    /** 用户代理 */
    private String userAgent;
    
    /** 操作状态（0：失败，1：成功） */
    private Integer status;
    
    /** 错误信息 */
    private String errorMessage;
    
    /** 创建时间 */
    private LocalDateTime createTime;
    
    /** 更新时间 */
    private LocalDateTime updateTime;
}
