-- ============================================================
-- 创建数据库
-- ============================================================
drop database if exists `ds0`;
drop database if exists `ds1`;
CREATE DATABASE IF NOT EXISTS `ds0` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE DATABASE IF NOT EXISTS `ds1` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- ============================================================
-- ds0：用户表 + 余额表 balance_1/2/3
-- ============================================================
USE `ds0`;

-- 用户表（分库：ds0/ds1 各一张）
CREATE TABLE IF NOT EXISTS `user`
(
    `user_id`     BIGINT      NOT NULL COMMENT '用户ID（分库分片键）',
    `username`    VARCHAR(64) NOT NULL COMMENT '用户名',
    `phone`       VARCHAR(20) DEFAULT NULL COMMENT '手机号',
    `level_id`    BIGINT      DEFAULT NULL COMMENT '用户等级ID（关联广播表 user_level）',
    `create_time` DATETIME    DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`user_id`),
    KEY `idx_username` (`username`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE = utf8mb4_unicode_ci COMMENT ='用户表（分库：ds0/ds1）';

-- 用户等级表（广播表：ds0/ds1 都有同结构同数据）
CREATE TABLE IF NOT EXISTS `user_level`
(
    `level_id`      BIGINT   auto_increment    NOT NULL COMMENT '等级ID（主键）',
    `level_name`    VARCHAR(50)  NOT NULL COMMENT '等级名称',
    `min_points`    INT          NOT NULL DEFAULT 0 COMMENT '最小积分',
    `max_points`    INT          NOT NULL DEFAULT 0 COMMENT '最大积分',
    `discount_rate` DECIMAL(5,2) NOT NULL DEFAULT 1.00 COMMENT '折扣系数（1.00=不打折）',
    `status`        TINYINT      NOT NULL DEFAULT 1 COMMENT '状态：1启用 0停用',
    `create_time`   DATETIME     DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time`   DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`level_id`),
    KEY `idx_status` (`status`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE = utf8mb4_unicode_ci COMMENT ='用户等级表（广播表）';

INSERT IGNORE INTO `user_level` (`level_id`, `level_name`, `min_points`, `max_points`, `discount_rate`, `status`)
VALUES (1, '普通会员', 0, 999, 1.00, 1),
       (2, '黄金会员', 1000, 4999, 0.95, 1),
       (3, '白金会员', 5000, 999999999, 0.90, 1);

-- 余额表：分表 balance_1、balance_2、balance_3（仅 ds0）
-- balance_1
CREATE TABLE IF NOT EXISTS `balance_1`
(
    `balance_id`  BIGINT         NOT NULL COMMENT '主键',
    `user_id`     BIGINT         NOT NULL COMMENT '用户ID（分表分片键）',
    `balance`     DECIMAL(18, 2) NOT NULL DEFAULT 0.00 COMMENT '余额',
    `create_time` DATETIME                DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME                DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`balance_id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE = utf8mb4_unicode_ci COMMENT ='用户余额表-1';

-- balance_2
CREATE TABLE IF NOT EXISTS `balance_2`
(
    `balance_id`  BIGINT         NOT NULL COMMENT '主键',
    `user_id`     BIGINT         NOT NULL COMMENT '用户ID（分表分片键）',
    `balance`     DECIMAL(18, 2) NOT NULL DEFAULT 0.00 COMMENT '余额',
    `create_time` DATETIME                DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME                DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`balance_id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE = utf8mb4_unicode_ci COMMENT ='用户余额表-2';

-- balance_3
CREATE TABLE IF NOT EXISTS `balance_3`
(
    `balance_id`          BIGINT        NOT NULL  COMMENT '主键',
    `user_id`     BIGINT        NOT NULL COMMENT '用户ID（分表分片键）',
    `balance`     DECIMAL(18,2) NOT NULL DEFAULT 0.00 COMMENT '余额',
    `create_time` DATETIME      DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`balance_id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE = utf8mb4_unicode_ci COMMENT ='用户余额表-3';

-- ============================================================
-- ds0：订单表 + 订单条目表（分表，绑定表）
-- ============================================================

-- 订单表分表：t_order_1、t_order_2（按 order_id 分片）
CREATE TABLE IF NOT EXISTS `t_order_1`
(
    `order_id`    BIGINT         NOT NULL COMMENT '订单ID（分表分片键）',
    `user_id`     BIGINT         NOT NULL COMMENT '用户ID',

    `amount`      DECIMAL(18, 2) NOT NULL DEFAULT 0.00 COMMENT '订单金额',
    `status`      VARCHAR(32)    NOT NULL DEFAULT 'CREATED' COMMENT '订单状态',
    `create_time` DATETIME                DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME                DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`order_id`),
    KEY `idx_user_id` (`user_id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE = utf8mb4_unicode_ci COMMENT ='订单表-1';

CREATE TABLE IF NOT EXISTS `t_order_2`
(
    `order_id`    BIGINT         NOT NULL COMMENT '订单ID（分表分片键）',
    `user_id`     BIGINT         NOT NULL COMMENT '用户ID',
    `amount`      DECIMAL(18, 2) NOT NULL DEFAULT 0.00 COMMENT '订单金额',
    `status`      VARCHAR(32)    NOT NULL DEFAULT 'CREATED' COMMENT '订单状态',
    `create_time` DATETIME                DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME                DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`order_id`),
    KEY `idx_user_id` (`user_id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE = utf8mb4_unicode_ci COMMENT ='订单表-2';

-- 订单条目表分表：t_order_item_1、t_order_item_2（按 order_id 分片，绑定 order）
CREATE TABLE IF NOT EXISTS `t_order_item_1`
(
    `order_item_id`          BIGINT         NOT NULL AUTO_INCREMENT COMMENT '主键',
    `order_id`    BIGINT         NOT NULL COMMENT '订单ID（分表分片键，与订单表绑定）',
    `product_id`  BIGINT         NOT NULL COMMENT '商品ID',
    `quantity`    INT            NOT NULL DEFAULT 1 COMMENT '数量',
    `price`       DECIMAL(18, 2) NOT NULL DEFAULT 0.00 COMMENT '单价',
    `create_time` DATETIME                DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME                DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`order_item_id`),
    KEY `idx_order_id` (`order_id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE = utf8mb4_unicode_ci COMMENT ='订单条目表-1';

CREATE TABLE IF NOT EXISTS `t_order_item_2`
(
    `order_item_id`          BIGINT         NOT NULL AUTO_INCREMENT COMMENT '主键',
    `order_id`    BIGINT         NOT NULL COMMENT '订单ID（分表分片键，与订单表绑定）',
    `product_id`  BIGINT         NOT NULL COMMENT '商品ID',
    `quantity`    INT            NOT NULL DEFAULT 1 COMMENT '数量',
    `price`       DECIMAL(18, 2) NOT NULL DEFAULT 0.00 COMMENT '单价',
    `create_time` DATETIME                DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME                DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`order_item_id`),
    KEY `idx_order_id` (`order_id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE = utf8mb4_unicode_ci COMMENT ='订单条目表-2';

-- ============================================================
-- ds1：用户表（分库，与 ds0 结构相同）
-- ============================================================
USE `ds1`;

CREATE TABLE IF NOT EXISTS `user`
(
    `user_id`     BIGINT      NOT NULL COMMENT '用户ID（分库分片键）',
    `username`    VARCHAR(64) NOT NULL COMMENT '用户名',
    `phone`       VARCHAR(20) DEFAULT NULL COMMENT '手机号',
    `level_id`    BIGINT      DEFAULT NULL COMMENT '用户等级ID（关联广播表 user_level）',
    `create_time` DATETIME    DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`user_id`),
    KEY `idx_username` (`username`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE = utf8mb4_unicode_ci COMMENT ='用户表（分库：ds0/ds1）';

CREATE TABLE IF NOT EXISTS `user_level`
(
    `level_id`      BIGINT  auto_increment     NOT NULL COMMENT '等级ID（主键）',
    `level_name`    VARCHAR(50)  NOT NULL COMMENT '等级名称',
    `min_points`    INT          NOT NULL DEFAULT 0 COMMENT '最小积分',
    `max_points`    INT          NOT NULL DEFAULT 0 COMMENT '最大积分',
    `discount_rate` DECIMAL(5,2) NOT NULL DEFAULT 1.00 COMMENT '折扣系数（1.00=不打折）',
    `status`        TINYINT      NOT NULL DEFAULT 1 COMMENT '状态：1启用 0停用',
    `create_time`   DATETIME     DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time`   DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`level_id`),
    KEY `idx_status` (`status`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE = utf8mb4_unicode_ci COMMENT ='用户等级表（广播表）';

INSERT IGNORE INTO `user_level` (`level_id`, `level_name`, `min_points`, `max_points`, `discount_rate`, `status`)
VALUES (1, '普通会员', 0, 999, 1.00, 1),
       (2, '黄金会员', 1000, 4999, 0.95, 1),
       (3, '白金会员', 5000, 999999999, 0.90, 1);

CREATE TABLE `log` (
  `log_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '日志ID',
  `user_id` bigint(20) DEFAULT NULL COMMENT '操作用户ID',
  `operation_type` varchar(50) DEFAULT NULL COMMENT '操作类型',
  `description` varchar(500) DEFAULT NULL COMMENT '操作描述',
  `request_method` varchar(10) DEFAULT NULL COMMENT '请求方法',
  `request_params` text COMMENT '请求参数',
  `response_result` text COMMENT '响应结果',
  `ip_address` varchar(50) DEFAULT NULL COMMENT '操作IP地址',
  `user_agent` varchar(500) DEFAULT NULL COMMENT '用户代理',
  `status` int(1) DEFAULT NULL COMMENT '操作状态（0：失败，1：成功）',
  `error_message` varchar(1000) DEFAULT NULL COMMENT '错误信息',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='日志表';