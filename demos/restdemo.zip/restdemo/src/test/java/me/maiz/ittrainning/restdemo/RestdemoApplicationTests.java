package me.maiz.ittrainning.restdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestdemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
