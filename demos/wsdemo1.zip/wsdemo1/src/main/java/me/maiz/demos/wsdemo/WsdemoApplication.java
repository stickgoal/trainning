package me.maiz.demos.wsdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WsdemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(WsdemoApplication.class, args);
    }

}
