package me.maiz.demos.wsdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WsdemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
