package me.maiz.shiro.shirojwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShirojwtApplicationTests {

    @Test
    void contextLoads() {
    }

}
