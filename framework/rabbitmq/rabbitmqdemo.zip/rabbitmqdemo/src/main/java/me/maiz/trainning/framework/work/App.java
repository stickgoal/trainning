package me.maiz.trainning.framework.work;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        new Worker().process(1);
        new Worker().process(2);

    }
}
