package me.maiz.trainning.framework.esdemo.repo;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import me.maiz.trainning.framework.esdemo.model.ESProduct;

public interface ProductDAO extends BaseMapper<ESProduct> {
}
