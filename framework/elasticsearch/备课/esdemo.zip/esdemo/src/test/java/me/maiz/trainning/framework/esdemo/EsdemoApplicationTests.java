package me.maiz.trainning.framework.esdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EsdemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
