package com.woniuxy.esquickstart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EsquickstartApplicationTests {

    @Test
    void contextLoads() {
    }

}
