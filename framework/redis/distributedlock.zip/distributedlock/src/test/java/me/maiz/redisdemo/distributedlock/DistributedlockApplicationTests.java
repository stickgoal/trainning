package me.maiz.redisdemo.distributedlock;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DistributedlockApplicationTests {

    @Test
    void contextLoads() {
    }

}
